#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import re

# Lecture des données d'entrée
for line in sys.stdin:
    # Suppression des espaces en début et en fin de ligne
    line = line.strip()
    # Découpage de la ligne en mots
    words = re.findall(r'\w+', line.lower())
    # Émission des paires clé-valeur
    for word in words:
        print("{0}\t{1}".format(word, 1))
