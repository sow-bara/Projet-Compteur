#!/usr/bin/env python3

# -*- coding: utf-8 -*-

import sys

# Initialisation du dictionnaire des mots et de leurs fréquences
word_freq = {}

# Lecture des données d'entrée
for line in sys.stdin:
    # Lecture de la paire clé-valeur
    word, count = line.strip().split('\t')
    count = int(count)

    # Mise à jour de la fréquence du mot
    if word in word_freq:
        word_freq[word] += count
    else:
        word_freq[word] = count

# Émission des résultats
for word, freq in word_freq.items():
    print("{0}\t{1}".format(word, freq))
